﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Blog.Common.Security
{
    public class SecurityService : ISecurityService
    {
        public string GetHashPassword(string text)
        {
            var sha1 = new SHA1CryptoServiceProvider();
            var sha1data = sha1.ComputeHash(GetBytesData(text));
            string savedPasswordHash = Convert.ToBase64String(sha1data);
            return savedPasswordHash;
        }
        public byte[] GetBytesData(string text) {
           return Encoding.ASCII.GetBytes(text);

        }
        
        
    }
}
