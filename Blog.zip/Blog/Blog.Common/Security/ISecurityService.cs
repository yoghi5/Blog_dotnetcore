﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.Common.Security
{
   public interface ISecurityService
    {
        public string GetHashPassword(string text);

        public byte[] GetBytesData(string text);
    }
}
