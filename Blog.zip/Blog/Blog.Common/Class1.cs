﻿using System;

namespace Blog.Common
{
    public class Class1
    {
    }
}
