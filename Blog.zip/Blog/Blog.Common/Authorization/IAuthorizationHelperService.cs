﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.Common.Authorization
{
    public interface IAuthorizationHelperService
    {
      
    }
}
