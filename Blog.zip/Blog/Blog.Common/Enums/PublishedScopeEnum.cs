﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.Common.Enums
{
    public enum PublishedScopeEnum
    {
        Private=1,
        Public=2
    }
}
