﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.ViewModels.Authorization
{
    public class LoginViewModel
    {
        public string EmailId { get; set; }
        public string Password { get; set; }
    }
}
