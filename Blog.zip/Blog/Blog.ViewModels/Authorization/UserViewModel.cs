﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Blog.ViewModels.Authorization
{
    public class UserViewModel
    {
        [Required]
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        [Required]
        public string EmailId { get; set; }
        public string ContactNumber { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public long RoleId { get; set; }
    }
}
