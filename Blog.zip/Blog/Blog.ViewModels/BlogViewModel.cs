﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Blog.ViewModels
{
    public class BlogViewModel
    {
        [Required]
        public string Title { get; set; }
        [Required]
        public string Body { get; set; }
        public string Summary { get; set; }
        public long? ParentBlogContentId { get; set; }
        [Required]
        public long CategoryId { get; set; }
    }
    public class UpdatelogViewModel: BlogViewModel
    {
        [Required]
        public long Id { get; set; }
    }

}
