﻿using Blog.Common.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.DataLayer.Models
{
    public interface IBaseModel
    {
        public bool IsDeleted { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public PublishedScopeEnum Published { get; set; }
        public bool IsActive { get; set; }
        public long CreatedBy { get; set; }
    }
}
