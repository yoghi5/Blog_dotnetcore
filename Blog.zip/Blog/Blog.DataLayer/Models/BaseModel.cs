﻿using Blog.Common.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Blog.DataLayer.Models
{
    public class BaseModel : IBaseModel
    {
        public BaseModel()
        {
            CreatedDate = DateTime.Now;
            IsActive = true;
            IsDeleted = false;
            Published = PublishedScopeEnum.Public;
        }
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public PublishedScopeEnum Published { get; set; }
        public bool IsActive { get; set; }
        public long CreatedBy { get; set; }
        public virtual Users Users { get; set; }
        public bool IsDeleted { get; set; }
    }
}
