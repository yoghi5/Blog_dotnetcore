﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Blog.DataLayer.Models
{
    public class BlogContents : BaseModel
    {
        [Required]
        public string Title { get; set; }
        [Required]
        public string Body { get; set; }
        public string Summary { get; set; }
        public long? ParentBlogContentId { get; set; }
        public virtual BlogContents BlogContent { get; set; }
        [Required]
        public long CategoryId { get; set; }
        public virtual Categories Category { get; set; }
    }
}

