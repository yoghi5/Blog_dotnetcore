﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.DataLayer.Models
{
    public class ApplicationDBContext : DbContext
    {
        public ApplicationDBContext(DbContextOptions options)
            : base(options)
        {
        }
        public DbSet<Users> Users { get; set; }
        public DbSet<Categories> Categories { get; set; }
        public DbSet<BlogContents> BlogContents { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseLazyLoadingProxies();
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Role>().HasData(
               new Role { Id = 1, Name = "Admin", IsActive = true },
                new Role { Id = 2, Name = "Blogger", IsActive = true },
               new Role { Id = 3, Name = "User", IsActive = true }

           );
            modelBuilder.Entity<Categories>().HasData(
              new Categories { Id = 1, Name = "AI and Machine Learning", IsActive = true },
               new Categories { Id = 2, Name = "Computer Science", IsActive = true },
              new Categories { Id = 3, Name = "Science", IsActive = true },
               new Categories { Id = 4, Name = "Cricket", IsActive = true }

          );
        }
    }
}
