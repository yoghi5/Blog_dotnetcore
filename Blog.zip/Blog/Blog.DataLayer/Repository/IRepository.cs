﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Blog.DataLayer.Models;

namespace Blog.DataLayer.Repository
{
   public interface IRepository<T> where T : class, IBaseModel
    {
        List<T> GetAll();
        T Add(T entity);
        T Update(T entity);

        /// <summary>
        /// get user records by paging
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="page"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortType"></param>
        /// <returns></returns>
        List<T> GetAllPaging<T>(int page, int pageSize, string sortType) where T : class, IBaseModel;
        T GetById<T2>(T2 id);
        IEnumerable<T> Find(Expression<Func<T, bool>> where, params Expression<Func<T, object>>[] includeProperties);
        IEnumerable<T> SqlQuery(string sql, params object[] parameters);
    }
}
