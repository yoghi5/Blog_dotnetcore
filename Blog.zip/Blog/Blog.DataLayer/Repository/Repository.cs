﻿using Blog.DataLayer.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Blog.DataLayer.Repository
{
    public class Repository<T> : IRepository<T> where T : class, IBaseModel
    {
        protected readonly ApplicationDBContext context;
        //private IRepository<User> userRepository;
        private DbSet<T> entities;
        public Repository(ApplicationDBContext context)
        {
            this.context = context;
            entities = context.Set<T>();
        }
        public T Add(T entity)
        {
            try
            {
                context.Set<T>().Add(entity);
                context.SaveChanges();
                return entity;
            }
            catch (Exception e)
            {
                throw new Exception(e.InnerException.Message);
            }

        }
        public List<T> GetAll()
        {
            return context.Set<T>().Where(s => s.IsDeleted == false).ToList();
            throw new NotImplementedException();
        }
        public T GetById<T2>(T2 id)
        {
            return context.Set<T>().Find(id);
            throw new NotImplementedException();
        }

        public IEnumerable<T> Find(Expression<Func<T, bool>> where, params Expression<Func<T, object>>[] includeProperties)
        {
            IQueryable<T> query = entities.AsQueryable();
            query = PerformInclusions(includeProperties, query);
            return query.Where(where);
        }
        public List<T> GetAllPaging<T>(int page, int pageSize, string sortType) where T : class, IBaseModel
        {
            switch (sortType)
            {
                case "asc":
                    return this.context.Set<T>().Skip(page * pageSize).Take(pageSize).Where(s => s.IsDeleted == false).OrderBy(s => s.CreatedDate).ToList();

                default:
                    return this.context.Set<T>().Skip(page * pageSize).Take(pageSize).Where(s => s.IsDeleted == false).OrderByDescending(s => s.CreatedDate).ToList();
            }

        }

        public T Update(T entity)
        {
            try
            {
                context.Entry(entity).State = EntityState.Modified;
                context.SaveChanges();
                return entity;
            }
            catch (Exception e)
            {
                throw new Exception(e.InnerException.Message);
            }
        }

        public List<T> FindByCondition<T>(Expression<Func<T, bool>> expression, int pageSize, int page, string sortType) where T : class, IBaseModel
        {
            switch (sortType.Trim().ToLower())
            {
                case "asc":
                    return this.context.Set<T>().Skip(page * pageSize).Take(pageSize).Where(s => s.IsDeleted == false).OrderBy(s => s.CreatedDate).Where(expression).AsNoTracking().ToList();
                default:
                    return this.context.Set<T>().Skip(page * pageSize).Take(pageSize).Where(s => s.IsDeleted == false).OrderByDescending(s => s.CreatedDate).Where(expression).AsNoTracking().ToList();
            }
        }

        private IQueryable<T> PerformInclusions(IEnumerable<Expression<Func<T, object>>> includeProperties, IQueryable<T> query)
        {
            return includeProperties.Aggregate(query, (current, includeProperty) => current.Include(includeProperty));

        }
        public IEnumerable<T> SqlQuery(string sql, params object[] parameters)
        {
            this.context.ChangeTracker.LazyLoadingEnabled = false;
            return context.Set<T>().FromSqlRaw(sql, parameters).AsNoTracking();
        }
    }
}

