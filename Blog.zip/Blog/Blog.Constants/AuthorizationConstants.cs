﻿using System;

namespace Blog.Constants
{
    public class AuthorizationConstants
    {
        public const string KEY = "XCXCXCXCKEYXCXCXCXCXC";
        public const string ADMIN_ROLE_NAME = "Admin";
    }
}
