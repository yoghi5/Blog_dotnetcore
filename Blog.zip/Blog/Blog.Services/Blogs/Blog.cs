﻿using Blog.DataLayer.Repository;
using Blog.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;
using Models = Blog.DataLayer.Models;
using System.Linq;
using Blog.Services.Interfaces;
using Blog.Constants;

namespace Blog.Services.Blogs
{
    public class Blog : IBlog
    {
        private readonly IRepository<Models.BlogContents> _blogContentsRepository = null;
        private readonly IRepository<Models.Users> _usersRepository = null;
        private readonly IRepository<Models.Role> _roleRepository = null;
        public Blog(IRepository<Models.BlogContents> blogContentsRepository, IRepository<Models.Role> roleRepository, IRepository<Models.Users> usersRepository)
        {
            _blogContentsRepository = blogContentsRepository;
            _roleRepository = roleRepository;
            _usersRepository = usersRepository;
        }
        /// <summary>
        /// Get all records with or without searching(partial search) in title or summary by set of pagination,
        /// </summary>
        /// <param name="page"></param>
        /// <param name="pageSize"></param>
        /// <param name="sort"></param>
        /// <param name="sortType"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public List<Models.BlogContents> GetAllBlog(string searchText, int page, int pageSize, string sort, string sortType)
        {
            if (page == 1 || page < 0)
                page = 0;
            string sqlQuery = "SELECT * FROM BlogContents WHERE IsDeleted=0  ";
            sqlQuery += searchText != null ? (" and Title LIKE \'%" + searchText + "%\' OR Summary LIKE \'% " + searchText + "%\'") : string.Empty;
            sqlQuery += "  order by " + sort + " " + sortType + " OFFSET " + page * pageSize + " ROWS FETCH NEXT " + pageSize + " ROWS ONLY ";

            List<Models.BlogContents> blogContents = _blogContentsRepository.SqlQuery(sqlQuery).ToList();
            return blogContents;
        }
        /// <summary>
        /// Add blog 
        /// </summary>
        /// <param name="blog">blog content data</param>
        public void AddBlog(BlogViewModel blog, long loginUserId)
        {
            Models.BlogContents blogContents = new Models.BlogContents
            {
                Title = blog.Title,
                Summary = blog.Summary,
                Body = blog.Body,
                ParentBlogContentId = blog.ParentBlogContentId,
                CategoryId = blog.CategoryId,
                CreatedBy = loginUserId
            };
            _blogContentsRepository.Add(blogContents);
        }
        /// <summary>
        /// update the blog
        /// </summary>
        /// <param name="blog"></param>
        public bool UpdateBlog(UpdatelogViewModel blog, long loginUserId)
        {
            if (blog.Id != 0)
            {
                Models.BlogContents blogContents = _blogContentsRepository.Find(s => s.Id == blog.Id && s.IsDeleted == false).FirstOrDefault();
                if (!ValidationUpdationProcess(blogContents, loginUserId))
                {
                    return false;
                }
                blogContents.Title = blog.Title;
                blogContents.Body = blog.Body;
                blogContents.CategoryId = blog.CategoryId;
                blogContents.Summary = blog.Summary;
                blogContents.ParentBlogContentId = blog.ParentBlogContentId;
                blogContents.ModifiedDate = DateTime.Now;
                blogContents.CreatedBy = loginUserId;
                _blogContentsRepository.Update(blogContents);
            }
            else
            {
                throw new Exception("Updation failed! missing primary key ");
            }
            return true;

        }
        /// <summary>
        /// Validating the data that it is updated by a valid user
        /// </summary>
        /// <param name="blog"></param>
        private bool ValidationUpdationProcess(Models.BlogContents blog, long loginUserId)
        {
            try
            {
                if (blog != null)
                {
                    Models.Users user = _usersRepository.Find(s => s.Id.Equals(loginUserId) && s.IsDeleted.Equals(false)).FirstOrDefault();
                    Models.Role role = _roleRepository.Find(s => s.Id.Equals(user.RoleId) && s.IsDeleted.Equals(false)).FirstOrDefault();
                    if (blog.CreatedBy != loginUserId && role.Name != AuthorizationConstants.ADMIN_ROLE_NAME)
                    {
                        return false;
                    }
                    return true;
                }
                else
                {
                    throw new Exception("No record found ");
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
        /// <summary>
        /// soft delete the blog
        /// </summary>
        /// <param name="id">blog id</param>
        public bool DeleteBlog(long id, long loginUserId)
        {
            if (id != 0)
            {
                Models.BlogContents blogContents = _blogContentsRepository.Find(s => s.Id == id && s.IsDeleted == false).FirstOrDefault();
                if (!ValidationUpdationProcess(blogContents, loginUserId))
                {
                    return false;
                }
                if (blogContents != null)
                {
                    blogContents.IsDeleted = true;
                    blogContents.CreatedBy = loginUserId;
                    blogContents.ModifiedDate = DateTime.Now;
                    _blogContentsRepository.Update(blogContents);
                }
                else
                {
                    throw new Exception("No record found for deletion");
                }
            }
            else
            {
                throw new Exception("Deletion failed! missing primary key ");
            }
            return true;
        }
    }
}
