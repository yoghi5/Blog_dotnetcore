﻿using Blog.DataLayer.Repository;
using Blog.Services.Interfaces;
using System.Linq;
using System;
using System.Collections.Generic;
using System.Text;
using Models = Blog.DataLayer.Models;
using Blog.ViewModels.Authorization;
using Blog.Common.Security;

namespace Blog.Services.Users
{
    public class User : IUser
    {
        private readonly IRepository<Models.Users> _userRepository = null;
        private readonly ISecurityService _securityService = null;
        public User(IRepository<Models.Users> userRepository, ISecurityService securityService) {
            _userRepository = userRepository;
            _securityService = securityService;
        }
        public Models.Users GetUserByEmailId(string emailId) {
            return _userRepository.Find(x => x.EmailId.Trim().ToLower().Equals(emailId.Trim().ToLower())).FirstOrDefault();
        }
        public void AddUser(UserViewModel userViewModel) {
            Models.Users user = new Models.Users
            {
                FirstName = userViewModel.FirstName,
                RoleId= userViewModel.RoleId,
                MiddleName = userViewModel.MiddleName,
                LastName = userViewModel.LastName,
                EmailId = userViewModel.EmailId,
                PasswordHash = _securityService.GetHashPassword(userViewModel.Password),
                Address = userViewModel.Address,
                ContactNumber = userViewModel.ContactNumber


            };
            _userRepository.Add(user);

        }
        public Models.Users VerifyLogin(LoginViewModel login) {
            string passwordHash = _securityService.GetHashPassword(login.Password);
            Models.Users user=_userRepository.Find(s => s.EmailId.Trim().ToLower().Equals(login.EmailId.Trim().ToLower()) && s.PasswordHash.Equals(passwordHash)).Select(s=>s).FirstOrDefault();
            return user;
        }
    }
}
