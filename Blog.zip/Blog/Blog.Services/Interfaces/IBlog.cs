﻿using Blog.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;
using Models = Blog.DataLayer.Models;

namespace Blog.Services.Interfaces
{
    public interface IBlog
    {
        public List<Models.BlogContents> GetAllBlog(string searchText,int page, int pageSize, string sort, string sortType);
        public bool UpdateBlog(UpdatelogViewModel blog, long loginUserId);

        public void AddBlog(BlogViewModel blog, long loginUserId);
        public bool DeleteBlog(long id, long loginUserId);
    }
}
