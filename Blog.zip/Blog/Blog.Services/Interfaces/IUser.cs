﻿using Blog.ViewModels.Authorization;
using System;
using System.Collections.Generic;
using System.Text;
using Models =Blog.DataLayer.Models;
namespace Blog.Services.Interfaces
{
    public interface IUser
    {
        Models.Users GetUserByEmailId(string emailId);
       void AddUser(UserViewModel user);
        Models.Users VerifyLogin(LoginViewModel login);
    }
}
