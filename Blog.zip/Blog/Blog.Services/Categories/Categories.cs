﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.Services.Categories
{
    public class Categories
    {
    }
}
