﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Blog.Common.Security;
using Blog.Constants;
using Blog.DataLayer.Models;
using Blog.DataLayer.Repository;
using Blog.Services.Interfaces;
using Blog.ViewModels.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace Blog.Controllers.Authorization
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IUser _userService = null;
        public AccountController(IUser userService)
        {
            _userService = userService;

        }
        [HttpPost]
        [AllowAnonymous]
        [Route("token")]
        public IActionResult Login(LoginViewModel loginModel)
        {
            var user = _userService.VerifyLogin(loginModel);
            // return null if user not found
            if (user == null)
                return StatusCode(StatusCodes.Status401Unauthorized, "Invalid login credentails"); ;

            // authentication successful so generate jwt token
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(AuthorizationConstants.KEY);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, user.Id.ToString()),
                    new Claim(ClaimTypes.Role, user.Role.Name),
                    // new Claim("RoleName", user.Role.Name.ToString())
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var tokenData = tokenHandler.WriteToken(token);
            return Ok(tokenData);
        }
        [HttpGet]
        [Authorize(Roles ="User,Admin")]
        [Route("testlogin")]
        public async Task<IActionResult> TestLogin()
        {
            return Ok();
        }
        [HttpGet]
        [AllowAnonymous]
        [Route("test")]
        public async Task<IActionResult> Test()
        {
            return Ok();
        }

        [HttpPost]
        [AllowAnonymous]
        [Route("register")]
        public async Task<IActionResult> Register(UserViewModel userViewModel)
        {
            try
            {
                  _userService.AddUser(userViewModel);
                return Ok();
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status400BadRequest, e.Message);
            }

        }
    }
}
