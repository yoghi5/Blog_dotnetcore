﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Blog.Services.Interfaces;
using Blog.ValidationFilter;
using Blog.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Blog.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BlogController : ControllerBase
    {
        private readonly IBlog _iblogService = null;
        public BlogController(IBlog iblogService)
        {
            _iblogService = iblogService;

        }
        [HttpGet]
        [Route("getall")]
        [Authorize(Roles = "Blogger,Admin")]
        public ActionResult GetAllBlog(string searchText, int pageNumber = 0, int pazeSize = 10, string sort = "CreatedDate", string sortBy = "Desc")
        {
            try
            {
                var blogData = _iblogService.GetAllBlog(searchText, pageNumber, pazeSize, sort, sortBy);
                return StatusCode(StatusCodes.Status200OK, blogData);
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status400BadRequest, e.Message);
            }
        }
        [HttpPost]
        [Route("add")]
        [Authorize(Roles = "Blogger,Admin")]
        public ActionResult AddBlog(BlogViewModel blog)
        {
            try
            {
                long _loginUserId = 0;
                long.TryParse(User.Identity.Name.ToString(), out _loginUserId);
                _iblogService.AddBlog(blog, _loginUserId);
                return StatusCode(StatusCodes.Status200OK, "Success");
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status400BadRequest, e.Message);
            }
        }

        [HttpPut]
        [Route("edit")]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        [Authorize(Roles = "Blogger,Admin")]
        public ActionResult UpdateBlog(UpdatelogViewModel blog)
        {
            try
            {
                long _loginUserId = 0;
                long.TryParse(User.Identity.Name.ToString(), out _loginUserId);
                if (!_iblogService.UpdateBlog(blog, _loginUserId))
                {
                    return StatusCode(StatusCodes.Status401Unauthorized, "Not authorized");
                }
                return StatusCode(StatusCodes.Status200OK);
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status400BadRequest, e.Message);
            }
        }
        [HttpDelete]
        [Route("delete")]
        [Authorize(Roles = "Blogger,Admin")]
        public ActionResult DeleteBlog(long id)
        {
            try
            {
                long _loginUserId = 0;
                long.TryParse(User.Identity.Name.ToString(), out _loginUserId);
                if (!_iblogService.DeleteBlog(id, _loginUserId)) {
                    return StatusCode(StatusCodes.Status401Unauthorized, "Not authorized");
                }
                return StatusCode(StatusCodes.Status200OK);
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status400BadRequest, e.Message);
            }
        }
    }
}
